var app = angular.module("site",["ui.bootstrap"]);

app.controller("ModalController",["$scope","$http","$uibModalInstance",function($scope,$http,$uibModalInstance){
	//alert(JSON.stringify($scope.objectsUpdate, null, 4));
	if(Object.keys($scope.objectsUpdate).length){
		$scope.uidUpdate = $scope.objectsUpdate.uid;
		$scope.statusflagUpdate = $scope.objectsUpdate.statusflag;
		$scope.codeUpdate = $scope.objectsUpdate.name;
		$scope.nameUpdate = $scope.objectsUpdate.detail;
		//$scope.forms.code = $scope.objectsUpdate.name;
		//$scope.forms.name = $scope.objectsUpdate.detail;
	}
	else{
		$scope.uidUpdate = "";
		$scope.statusflagUpdate = "A";
		$scope.codeUpdate = "";
		$scope.nameUpdate = "";
	}
	$scope.OK = function(){
		$uibModalInstance.close();
	};
	$scope.Cancel = function(){
		$uibModalInstance.dismiss("cancel");
	};
	$scope.Submit = function() {
		if(Object.keys($scope.objectsUpdate).length){
			//alert("UPDATE : " + JSON.stringify($scope.forms,null,4));return;
			$http.post("/site/update",$scope.forms)
				.success(function(data){
					$scope.results.length = 0;
					$scope.results.push.apply($scope.results,data.results)
					$uibModalInstance.close(data);
				})
				.error(function(err){
					$log.error(err);
					$scope.message = err;
					alert(JSON.stringify(err,null,4));
				});
		}
		else{
			//alert("INSERT : " + JSON.stringify($scope.forms,null,4));return;
			$http.post("/site/insert",$scope.forms)
				.success(function(data) {
					$scope.header = data.header;
					$scope.results.length = 0;
					$scope.results.push.apply($scope.results,data.results)
					$scope.forms.code = "";
					$scope.forms.name = "";
					$scope.formDefault.$setValidity();//Clear Validate
					$scope.formDefault.$setPristine();//Reset Invalid Checker
					$scope.formDefault.$setUntouched();//Clear Touched
					$uibModalInstance.close(data);
				})
				.error(function(err) {
					$log.error(err);
					$scope.message = err;
					alert(JSON.stringify(err,null,4));
				});
		}
	};

}]);

app.controller("SiteController",["$scope", "$http", "$uibModal", "$log", function($scope, $http, $uibModal, $log) {

	$http.get("/site/select")
		.success(function(data) {
			this.title = data.title;
			$scope.header = data.header;
			$scope.results = data.results;
		})
		.error(function(err) {
			$log.error(err);
		});

    $scope.ShowModalInsert = function(){
    	$scope.objectsUpdate = [];
        var modalInstance = $uibModal.open({
        	templateUrl:"modalDefault.html",
        	controller:"ModalController",
        	scope:$scope
        });
        modalInstance.result.then(function(results){
        	//alert(results.name);
        });
    };
    $scope.ShowModalUpdate = function(objects){
    	$scope.objectsUpdate = objects;
        var modalInstance = $uibModal.open({
        	templateUrl:"modalDefault.html",
        	controller:"ModalController",
        	scope:$scope
        });
        modalInstance.result.then(function(results){
        	//alert(results.name);
        });
    };

	$scope.Delete = function($params) {
		var cnfrm = confirm("Are you sure to delete?");
		if(cnfrm) {
			$http.post("/site/delete", {"uid":$params})
			.success(function(data) {
				$scope.header = data.header;
				$scope.results = data.results;
			})
			.error(function(err) {
				$log.error(err);
				$scope.message = err;
			})
		} else {
			// 
		}
	};

}]);