var pg = require("pg");
var appRoot = process.cwd();
var config = require(appRoot + "/config/config");
//var config = require("../../config/config");
var connectionString = config.pgUri;

exports.render = function(request,response){
	var message = "";
	var results = [];

	var clsSQL = require("../myclass/clsSQL");
	clsSQL.select("SELECT uid,name,detail,statusflag,cwhen FROM site;",function(errors,resultsReturn){
		if(errors){
			console.log("Results : " + errors);
			response.render("site",{
				success:false,
				title:"Site Manage",
				header:"ระบบจัดการข้อมูลโรงพยาบาล",
				message:errors,
				results:null
			});
		}
		else{
			response.render("site",{
				success:true,
				title:"Site Manage",
				header:"ระบบจัดการข้อมูลโรงพยาบาล",
				message:"",
				results:resultsReturn
			});
		}
	});
}
exports.insert = function(request,response){
	//express-validator check
	request.checkBody("txtCode","Please fill code.").notEmpty();
	var errors = request.validationErrors();
	if(errors){
		response.render("site",{
			success:false,
			title:"Site Manage",
			header:"Site Manage Fail on Insert",
			message:"Please fill code : " + JSON.stringify(errors),
			results:null
		});
		return;
	}

	pg.connect(connectionString, function(errors,client,done){
		var results = [];
		if(errors){
			done();
			response.render("site",{
				success:false,
				title:"Site Manage",
				header:"Site Manage Fail on Connecting DB",
				message:errors,
				results:null
			});
		}
		//SQL Query : INSERT
		client.query("INSERT INTO site(name,detail)VALUES($1,$2);",[request.body.txtCode,request.body.txtName])
		//SQL Query : SELECT
		var query = client.query("SELECT uid,name,detail,statusflag,cwhen FROM site;")
		//Stream result back row at a time
		query.on("row",function(row){
			results.push(row);
		});
		//After all data is returned, close connection and return results
		query.on("end",function(){
			done();
			response.render("site",{
				success:true,
				title:"Site Manage",
				header:"Site Manage : Save Completed",
				results:results
			});
		});
	});
}
exports.edit = function(request,response){
	response.render("site",{
		success:true,
		title:"Has params" + request.params.uid,
		header:"Has params : " + request.params.uid
	});
}