module.exports = function(app){
	var site = require("../controllers/site.server.controllers");
	app.get("/site",site.render);
	app.post("/site",site.insert);
	app.get("/site/:uid",site.edit);
}